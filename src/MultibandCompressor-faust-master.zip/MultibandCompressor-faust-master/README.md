A mono and stereo multiband compressor written in faust.

You can create vst,ladspa,jack and other plugins by installing faust
and run his tools this way:

faust2ladspa ./MultibandCompressor_stereo.dsp


